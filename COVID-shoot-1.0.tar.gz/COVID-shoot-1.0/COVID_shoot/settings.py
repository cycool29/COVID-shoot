covid_speed_type = 'Fast'
